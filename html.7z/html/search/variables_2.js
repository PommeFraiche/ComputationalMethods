var searchData=
[
  ['c',['C',['../class_scheme.html#a82dfad10d652532e784065057f1acb63',1,'Scheme']]]
];
