var searchData=
[
  ['explicitupwind',['ExplicitUpwind',['../class_explicit_upwind.html',1,'']]]
];
