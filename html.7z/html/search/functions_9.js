var searchData=
[
  ['scheme',['Scheme',['../class_scheme.html#aa0b319a6594176dea40ca78562401b53',1,'Scheme::Scheme()'],['../class_scheme.html#a947dcc57133f8ba92ab667e63631c76c',1,'Scheme::Scheme(double dx, double dt, double u, double xmax, double tmax)']]],
  ['solve',['solve',['../class_explicit_upwind.html#a5e5f959782338ccadd12a7ce24ca0a1a',1,'ExplicitUpwind::solve()'],['../class_f_t_c_s.html#a0951ebb771757008cba5588cda2603dd',1,'FTCS::solve()'],['../class_implicit_upwind.html#ab0838d6dc2af3c34dd26cbffa8d4fde4',1,'ImplicitUpwind::solve()'],['../class_lax_wendroff.html#a067721cda954dfb018a3a3b03935b1d8',1,'LaxWendroff::solve()']]]
];
