var searchData=
[
  ['errornorm1',['ErrorNorm1',['../class_scheme.html#ad6266c4357063fe372480b61ff04b6ee',1,'Scheme']]],
  ['errornorm2',['ErrorNorm2',['../class_scheme.html#a2bff82429fd2910f94b8d70218f9ccf2',1,'Scheme']]],
  ['errornorminf',['ErrorNormInf',['../class_scheme.html#aef2e6b4c6677eacdad54debf8b98d51e',1,'Scheme']]],
  ['explicitupwind',['ExplicitUpwind',['../class_explicit_upwind.html#a3b8e082f1fed6e3903659dbb2d9ac7fd',1,'ExplicitUpwind']]]
];
