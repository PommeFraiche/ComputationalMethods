var searchData=
[
  ['solution',['solution',['../main_8cpp.html#a22928f5bb7e2c0ac38991b572fd96766',1,'main.cpp']]]
];
