var searchData=
[
  ['getncols',['getNcols',['../class_matrix.html#ae0a5f2154953b8d129a90b04f91d9079',1,'Matrix']]],
  ['getnrows',['getNrows',['../class_matrix.html#a711f84a1c62832d9d197d78c9855a276',1,'Matrix']]]
];
