var searchData=
[
  ['implicitupwind',['ImplicitUpwind',['../class_implicit_upwind.html',1,'']]]
];
